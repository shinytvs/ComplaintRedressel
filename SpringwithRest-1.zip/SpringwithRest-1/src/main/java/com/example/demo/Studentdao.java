package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Studentdao {
	

@Autowired
Studentrepo srepo;

//insert single student
public Student insertStudent(Student s)
{return srepo.save(s);}

//get all student
public List<Student> getAll()
{
	return srepo.findAll();}


//fetch by Id
public Student getbyid(int id)
{ return srepo.findById(id).orElse(null);
}


//insert a collection
public  List<Student> insertAll(List<Student> s)
{return srepo.saveAll(s);}

public String deleteByid(int id)
{
srepo.deleteById(id);
String s="deleted th eid"+ id;
return s;
}
 

//update-find the value n update save
public Student update(Student s)
{
	
Student newstd=srepo.findById(s.getId()).orElse(null);
newstd.setName("Pavan");
return srepo.save(newstd);
	
}
}






