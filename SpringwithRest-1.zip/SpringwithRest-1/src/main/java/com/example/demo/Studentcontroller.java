package com.example.demo;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Studentcontroller
{
	
	@Autowired
	Studentdao sd;
	
	/*@RequestMapping("/")
    public String home() {
        System.out.println("Going home...");
        return "index";
    }
*/	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
	    List<Student> student = sd.getAll();
	    model.addAttribute("listStudents", student);
	     
	    return "first";
	}
	
	@RequestMapping("/new")
	public String showNewStudentPage(Model model) {
	    Student std = new Student();
	    model.addAttribute("student",std);
	     
	    return "newstudent";
	}
	
	@RequestMapping("insert")
	public ModelAndView insert(@RequestParam("name") String name,@RequestParam("email") String email,HttpServletRequest res,HttpServletResponse rep)
	{
	ModelAndView mv= new ModelAndView();
	Student s=new Student();
	s.setName(name);
	s.setEmail(email);
	if(s==null)
		mv.setViewName("index");
   Student sp=sd.insertStudent(s);
	if(sp!=null)
	{
	mv.setViewName("status");}
	else
	{mv.setViewName("index");
	
	}
	return mv;}
	
	@RequestMapping("getall")
	public ModelAndView get(HttpServletRequest res,HttpServletResponse rep)
	{
	ModelAndView mv= new ModelAndView();
	List<Student> s =sd.getAll();
	mv.setViewName("display");
	mv.addObject("list",s);
	return mv;
	}

	
	@RequestMapping(value="/delete",method = RequestMethod.GET)    
	public String  delete(@RequestParam int id,HttpServletRequest req,HttpServletResponse res)
	{  
		//ModelAndView mv=new ModelAndView();
		System.out.println("value"+id);
		sd.deleteByid(id);
		System.out.println("executed");
		return "redirect:/getall";

	    
	}   
	
	@RequestMapping(value = "/save",  method = { RequestMethod.GET, RequestMethod.POST })
	public String saveProduct(@ModelAttribute("student") Student student) {
	     sd.srepo.save(student);
         return "redirect:/";
	}
	
	@RequestMapping("save")
	public ModelAndView savestudent(@RequestParam("name") String name,@RequestParam("email") String email,@RequestParam("id") int id,
			HttpServletRequest res,HttpServletResponse rep)
	{
	ModelAndView mv= new ModelAndView();
	Student s=new Student();
	s.setId(id);
	s.setName(name);
	s.setEmail(email);
   Student sp=sd.insertStudent(s);
	if(sp!=null)
	{mv.setViewName("status");
	
	}
	return mv;}

	
	@RequestMapping(value="/update", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView update(@RequestParam int id,HttpServletRequest req,HttpServletResponse res) {
		ModelAndView mav = new ModelAndView("updatestd");
		Student std = sd.getbyid(id);
		mav.addObject("student", std);
		return mav;
		
	}
	
	
	/*@RequestMapping("register")
	public ModelAndView register(@RequestParam("email") String email,HttpServletRequest res,HttpServletResponse rep)
	{
	ModelAndView mv= new ModelAndView();
	Student s=new Student();
	//s.setName(name);
	s.setEmail(email);
   
	Student sp=sd.getbyemail(email);
	if(sp!=null)
	{mv.setViewName("login");
	}
	return mv;*/
}
