package com.ems.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ems.constants.Results;
import com.ems.dbconnector.DBConnector;


public class ValidateDao 
{

public String validateEmpid(int id)
{
	
			String result=null;
			String qry="select * from employeedetails where EmpID = ?";
	try
	{
		PreparedStatement stmt= DBConnector.getPreparedStatement(qry);
		stmt.setInt(1,id);
		ResultSet rs = stmt.executeQuery();
		if(rs.next())
		{
			result=Results.SUCCESS;}
			else{
			result=Results.FAILIURE;
		}
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
	return result;
}			
}

