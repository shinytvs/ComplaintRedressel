package com.ems.daoimpl;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.ems.constants.Results;
import com.ems.dbconnector.DBConnector;
import com.ems.entity.Compliance;


public class ComplianceDao {

	public  static ArrayList<Compliance> viewAllRegulations()
	{
		ArrayList<Compliance> list = new ArrayList<Compliance>();
		String qry="select * from complianc";
		try
		{
		PreparedStatement pstmt = DBConnector.getPreparedStatement(qry);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			//System.out.println(rs.getString(1));
			Compliance cp= new Compliance();
			cp.setComplianceid(rs.getInt(1));
			cp.setRLType(rs.getString(2));
			cp.setDetails(rs.getString(3));
			cp.setCrtdate(rs.getString(4));
			cp.setDeptid(rs.getInt(5));
			
			list.add(cp);
		}
		}
		catch(Exception ex)
		{ex.printStackTrace();}
		return list;}
	
	public static String insertRegulations(Compliance cp)
	{
		// TODO Auto-generated method stub
		System.out.println("in method");
		String s= null;
	String query ="insert into complianc (CompliaceId,RLType,Details,CreateDate,deptid) values(?,?,?,?,?)";
	
	try
	{
		PreparedStatement pstmt= DBConnector.getPreparedStatement(query);
		pstmt.setInt(1,cp.complianceid);
		pstmt.setString(2,cp.RLType);
		pstmt.setString(3,cp.details);
		
		pstmt.setString(4,cp.crtdate);
		
		pstmt.setInt(5,cp.deptid);
        
	int i = pstmt.executeUpdate();
	if(i==1)
	{
		s = Results.SUCCESS;
		System.out.println("success");
	}else
	{
		System.out.println("fail");
		s= Results.FAILIURE;
		
	}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	s = Results.PROBLEM;
	}
	return s;
}
}


