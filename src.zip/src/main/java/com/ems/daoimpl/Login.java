package com.ems.daoimpl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.ems.dbconnector.DBConnector;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out =  response.getWriter();
		//String ename=null;
		try
		{
			System.out.println("enter login");
			String qry = "select * from login";
  	  //Statement stm = c.createStatement();
		//	Statement stm = DatabaseConnector.getStatement();

      ResultSet rs = DBConnector.getResultSet(qry);
    		  //stm.executeQuery("select * from accounts");

      
      String s= request.getParameter("username");
		String s1= request.getParameter("password");
		String s2=request.getParameter("usertype");
		//String x= rs.getString("role");
		//System.out.println(st);
        System.out.println(s);
		System.out.println(s1);
		System.out.println(s2);
		while(rs.next())
		{
			if(rs.getString("username").equals(s) && (rs.getString("password").equals(s1)&&rs.getString("role").equals("Admin")))
			{
				//if(rs.getString("role").equals("Admin"))
				
			//	{
					System.out.println("inside sessionadmin"+s);
					HttpSession ssn = request.getSession();
					ssn.setAttribute("ename", s);
					RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
					rd.forward(request, response);
				}
				else if(rs.getString("username").equals(s) && (rs.getString("password").equals(s1)&&rs.getString("role").equals("User")))
					//if(s2.equals("User"))
						{
					System.out.println("insider user page");
					HttpSession session = request.getSession();
					session.setAttribute("ename",s);
					RequestDispatcher rd= request.getRequestDispatcher("user.jsp");
					rd.forward(request, response);
					
						}
				else if(rs.getString("username").equals(s) && (rs.getString("password").equals(s1)&&rs.getString("role").equals("DeptHead")))
					//if(rs.getString("role").equals("DeptHead"))
				{
				System.out.println("inside depthead page");	
			HttpSession session = request.getSession();
			session.setAttribute("ename",s);
			RequestDispatcher rd= request.getRequestDispatcher("dptHd.jsp");
			rd.forward(request, response);
			
				}
				else
					
				{  out.println("Either you enter Invalid UserName or Password! Please Try Again");
		         // out.println("Username or Password incorrect");
		          RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		          rd.include(request, response);}
			}
			
		
		}
				catch(Exception e)
				{
					System.out.println(e);
					e.printStackTrace();
				}
				
		}
				
				  }
					
	
