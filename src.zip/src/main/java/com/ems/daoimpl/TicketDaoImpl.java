package com.ems.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.ems.constants.Results;
import com.ems.dbconnector.DBConnector;
import com.ems.entity.Employee;
import com.ems.entity.StatusReport;
import com.ems.entity.Tickets;

public class TicketDaoImpl
{
	public  static ArrayList<Tickets> viewAllTickets()
	{
		ArrayList<Tickets> list = new ArrayList<Tickets>();
		String qry="select * from tickets";
		try
		{
		PreparedStatement pstmt = DBConnector.getPreparedStatement(qry);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			//System.out.println(rs.getString(1));
			Tickets cp= new Tickets();
			cp.setTktid(rs.getInt(1));
			cp.setEmpid(rs.getInt(2));
			cp.setTicket(rs.getString(3));
			cp.setStatus(rs.getString(4));
			cp.setEmpname(rs.getString(5));
			cp.setCrtdate(rs.getString(6));
			
			
			list.add(cp);
		}
		}
		catch(Exception ex)
		{ex.printStackTrace();}
		return list;}
	
	public  Tickets getTicket(int tktid)
	{
		// TODO Auto-generated method stub
		Tickets cp = null;
		String qry="select * from tickets where Id = ?";
		try
		{
			PreparedStatement stmt= DBConnector.getPreparedStatement(qry);
			stmt.setInt(1,tktid);
			ResultSet rs = stmt.executeQuery();
			if(rs.next())
			{
				
				cp = new Tickets();
			
				cp.setTktid(rs.getInt(1));
				cp.setEmpid(rs.getInt(2));
				cp.setTicket(rs.getString(3));
				cp.setStatus(rs.getString(4));
				cp.setEmpname(rs.getString(5));
				cp.setCrtdate(rs.getString(6));
				
				
				
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return cp;
	}
	
	
	public  ArrayList<Tickets> viewDetails(int empid)
	{
		System.out.println("1");
		ArrayList<Tickets> list = new ArrayList<Tickets>();
		String query="select * from tickets  where empid = ?";
	  System.out.println();
		try
		{
	    System.out.println("2");
		PreparedStatement pstmt = DBConnector.getPreparedStatement(query);
		
		pstmt.setInt(1,empid);
		
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{System.out.println("2");
		Tickets cp= new Tickets();
		cp.setTktid(rs.getInt(1));
		cp.setEmpid(rs.getInt(2));
		cp.setTicket(rs.getString(3));
		cp.setStatus(rs.getString(4));
		cp.setEmpname(rs.getString(5));
		cp.setCrtdate(rs.getString(6));
		
		
		list.add(cp);
	}
	}
	catch(Exception ex)
	{ex.printStackTrace();}
	return list;}
	
	
	public static String updateTickets(Tickets t) {
		// TODO Auto-generated method stub
		
		//String query="update tickets set empid=?,ticket=?,Status=?,Employee=?,CrtDate=? where Id = ?";
		String query ="update tickets set empid=?,ticket=?,Status=?,Employee=?,CrtDate=? where Id = ?";
		System.out.println(query);
		String result= null;
		try{
			PreparedStatement pstmt= DBConnector.getPreparedStatement(query);
			
			pstmt.setInt(6, t.tktid);
			pstmt.setInt(1,t.empid);
			pstmt.setString(2,t.ticket);
			pstmt.setString(3, t.status);
			pstmt.setString(4,t.empname);
			pstmt.setString(5 , t.crtdate);
			int i = pstmt.executeUpdate();
			
			System.out.println(i);
			if(i==1)
			{result=Results.SUCCESS;}
			else
			{result=Results.FAILIURE;}
				
		}
		catch(Exception ex)
		{ex.printStackTrace();
		 result = Results.PROBLEM;
		
		}
		return result;
	}
	
	
}
