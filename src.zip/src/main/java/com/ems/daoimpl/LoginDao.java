package com.ems.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ems.dbconnector.DBConnector;
import com.ems.entity.Employee;
import com.ems.entity.Login;

public class LoginDao
{
	public static boolean validatelogin(String role,String name,String password)
	{
		
		boolean status = false;
  String query="select * from login  where role = ? and username = ? and password = ?";
	
		try
		{
	    
		PreparedStatement pstmt = DBConnector.getPreparedStatement(query);
		
		pstmt.setString(1,role);
		
		pstmt.setString(2,name);
		pstmt.setString(3,password);
       
		ResultSet rs=pstmt.executeQuery();
		
		status=rs.next();  
		System.out.println(status);
		System.out.println(query);  
		}catch(Exception e){System.out.println(e);}  
		System.out.println(status);
		return status;  
		}
	
	public  Login getEmployeebyname(String empname)
	{
		// TODO Auto-generated method stub
		String s= empname;
		System.out.println(s);
		Login e = null;
		String qry="select * from login where username = ?";
		try
		{
			System.out.println(s);
			PreparedStatement stmt= DBConnector.getPreparedStatement(qry);
			System.out.println(s);
			stmt.setString(1,empname);
			System.out.println(s);
			ResultSet rs = stmt.executeQuery();
			System.out.println(s);
			while(rs.next())
			{
				System.out.println(s);
				e = new Login();
				e.setId(rs.getInt(1));
				e.setPassword(rs.getString(2));
				e.setRole(rs.getString(3));
				e.setUsername(rs.getString(4));
				
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return e;
	}

		
		}
	
