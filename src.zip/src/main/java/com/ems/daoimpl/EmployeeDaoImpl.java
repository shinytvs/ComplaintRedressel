package com.ems.daoimpl;
import com.ems.constants.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
//import java.util.List;

import com.ems.entity.Employee;

import com.ems.dbconnector.*;

public class EmployeeDaoImpl
{

	public  static ArrayList<Employee> viewAllEmployee()
	{
		ArrayList<Employee> list = new ArrayList<Employee>();
		String qry="select * from employeedetails";
		try
		{
		PreparedStatement pstmt = DBConnector.getPreparedStatement(qry);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			//System.out.println(rs.getString(1));
			Employee ae =new Employee();
			ae.setEmpid(rs.getInt(1));
			ae.setEmpname(rs.getString(2));
			ae.setLname(rs.getString(3));
		    ae.setDob(rs.getString(4));
			ae.setEmail(rs.getString(5));
			ae.setDeptid((rs.getInt(6)));
			
			list.add(ae);
		}
		}
		catch(Exception ex)
		{ex.printStackTrace();}
		return list;}

	public  ArrayList<Employee> getEmpbydept(int deptid)
	{
		System.out.println("1");
		ArrayList<Employee> list = new ArrayList<Employee>();
		String query="select * from employeedetails  where deptid = ?";
	
		try
		{
	    System.out.println("2");
		PreparedStatement pstmt = DBConnector.getPreparedStatement(query);
		
		pstmt.setInt(1,deptid);
		
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{System.out.println("2");
			Employee ae= new Employee();
			ae.setEmpid(rs.getInt(1));
			ae.setEmpname(rs.getString(2));
			ae.setLname(rs.getString(3));
		    ae.setDob(rs.getString(4));
			ae.setEmail(rs.getString(5));
			ae.setDeptid((rs.getInt(6)));
		
			
			list.add(ae);		
		}
		
		}
	
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
        return list;
		
	}
	

	public  Employee getEmployee(int empid)
	{
		// TODO Auto-generated method stub
		Employee e = null;
		String qry="select * from employeedetails where EmpID = ?";
		try
		{
			PreparedStatement stmt= DBConnector.getPreparedStatement(qry);
			stmt.setInt(1,empid);
			ResultSet rs = stmt.executeQuery();
			if(rs.next())
			{
				e = new Employee();
				e.setDeptid(rs.getInt(6));
				e.setDob(rs.getString(4));
				e.setEmail(rs.getString(5));
				e.setEmpid(rs.getInt(1));
				e.setEmpname(rs.getString(2));
				e.setLname(rs.getString(3));
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return e;
	}
	
	public   Employee getEmployeebyname(String empname)
	{
		// TODO Auto-generated method stub
		String s= empname;
		System.out.println(s);
		Employee e = null;
		String qry="select * from employeedetails where EmpName = ?";
		try
		{
			System.out.println(s);
			PreparedStatement stmt= DBConnector.getPreparedStatement(qry);
			System.out.println(s);
			stmt.setString(1,empname);
			System.out.println(s);
			ResultSet rs = stmt.executeQuery();
			System.out.println(s);
			while(rs.next())
			{
				System.out.println(s);
				e = new Employee();
				e.setDeptid(rs.getInt(6));
				e.setDob(rs.getString(4));
				e.setEmail(rs.getString(5));
				e.setEmpid(rs.getInt(1));
				e.setEmpname(rs.getString(2));
				e.setLname(rs.getString(3));
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return e;
	}

	public static String updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
		String query="update employeedetails set EmpName=?,LName=?,DOB=?,Email=?,DeptID=? where EmpID = ?";
		String result= null;
		try{
			PreparedStatement pstmt= DBConnector.getPreparedStatement(query);
			
			pstmt.setString(1, emp.empname);
			pstmt.setString(2,emp.lname);
			pstmt.setString(3,emp.dob);
			pstmt.setString(4,emp.email);
			pstmt.setInt(5,emp.deptid);
			pstmt.setInt(6,emp.empid);
			int i = pstmt.executeUpdate();
			if(i==1)
			{result=Results.SUCCESS;}
			else
			{result=Results.FAILIURE;}
				
		}
		catch(Exception ex)
		{ex.printStackTrace();
		 result = Results.PROBLEM;
		
		}
		return result;
	}
	
	
	public static String deleteEmployee(int id)
	{
		String query = "delete from employeedetails where EmpID=?";
		String result=null;
		try

		{
			PreparedStatement pstmt = DBConnector.getPreparedStatement(query);
			
			pstmt.setInt(1,id);
			System.out.println(query);
			int i = pstmt.executeUpdate();
			System.out.println(query);
			if(i==1)
			{result=Results.SUCCESS;}
			else
			{result=Results.FAILIURE;}
				
		}
		catch(Exception ex)
		{ex.printStackTrace();
		 result = Results.PROBLEM;
		
		}
		return result;
		
		
		// TODO Auto-generated method stub
		
	}

	public static String insertEmployee(Employee emp)
	{
		// TODO Auto-generated method stub
		String s= null;
	String query ="insert into employeedetails (EmpID,EmpName,LName,DOB,Email,DeptID) values(?,?,?,?,?,?)";
	
	try
	{
		PreparedStatement pstmt= DBConnector.getPreparedStatement(query);
		pstmt.setInt(1,emp.empid);
		pstmt.setString(2,emp.empname);
		pstmt.setString(3,emp.lname);
		pstmt.setString(4,emp.dob);
		pstmt.setString(5,emp.email);
		pstmt.setInt(6,emp.deptid);
	
	int i = pstmt.executeUpdate();
	if(i==1)
	{
		s = Results.SUCCESS;
	}else
	{
		s= Results.FAILIURE;
	}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	s = Results.PROBLEM;
	}
	return s;
}
	
	public   Employee getEmpByname(String empname)
	{
		// TODO Auto-generated method stub
		String s= empname;
		System.out.println(s);
		Employee e = null;
		String qry="select * from login where EmpName = ?";
		try
		{
			System.out.println(s);
			PreparedStatement stmt= DBConnector.getPreparedStatement(qry);
			System.out.println(s);
			stmt.setString(1,empname);
			System.out.println(s);
			ResultSet rs = stmt.executeQuery();
			System.out.println(s);
			while(rs.next())
			{
				System.out.println(s);
				e = new Employee();
				e.setDeptid(rs.getInt(6));
				e.setDob(rs.getString(4));
				e.setEmail(rs.getString(5));
				e.setEmpid(rs.getInt(1));
				e.setEmpname(rs.getString(2));
				e.setLname(rs.getString(3));
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return e;
	}

}
