package com.ems.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.ems.constants.Results;
import com.ems.dbconnector.DBConnector;
import com.ems.entity.Department;


public class DeptDao {

	public  static ArrayList<Department> viewDepartment()
	{
		ArrayList<Department> list = new ArrayList<Department>();
		String qry="select * from department";
		try
		{
		PreparedStatement pstmt = DBConnector.getPreparedStatement(qry);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			//System.out.println(rs.getString(1));
			Department dp =new Department();
			dp.setDeptid(rs.getInt(1));
			dp.setDeptname(rs.getString(2));
			dp.setDeptno(rs.getInt(3));
		
			
			list.add(dp);
		}
		}
		catch(Exception ex)
		{ex.printStackTrace();}
		return list;}





public static String insertDepartment(Department dp)
{
	// TODO Auto-generated method stub
	String s= null;
String query ="insert into department (deptid,deptname,deptno) values(?,?,?)";

try
{
	PreparedStatement pstmt= DBConnector.getPreparedStatement(query);
	pstmt.setInt(3,dp.deptno);
	pstmt.setString(2,dp.deptname);
	
	pstmt.setInt(1,dp.deptid);

int i = pstmt.executeUpdate();
if(i==1)
{
	s = Results.SUCCESS;
}else
{
	s= Results.FAILIURE;
}
}
catch(Exception e)
{
	e.printStackTrace();
s = Results.PROBLEM;
}
return s;
}
}
