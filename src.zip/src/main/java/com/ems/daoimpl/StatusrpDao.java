package com.ems.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.ems.constants.Results;
import com.ems.dbconnector.DBConnector;

import com.ems.entity.StatusReport;

public class StatusrpDao
{


	public  ArrayList<StatusReport> viewDetails(int empid)
	{
		System.out.println("1");
		ArrayList<StatusReport> list = new ArrayList<StatusReport>();
		String query="select * from statusreport  where empid = ?";
	
		try
		{
	    System.out.println("2");
		PreparedStatement pstmt = DBConnector.getPreparedStatement(query);
		
		pstmt.setInt(1,empid);
		
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{System.out.println("2");
			StatusReport sr = new StatusReport();
			
			sr.setComments(rs.getString(6));
			sr.setComplianceid(rs.getInt(2));
			sr.setDate1(rs.getString(7));
			sr.setDeptid(rs.getInt(5));
			sr.setEmpid(rs.getInt(4));
			sr.setId(rs.getInt(1));
			sr.setStatusreport(rs.getString(3));
			
			list.add(sr);		
		}
		
		}
	
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
        return list;
		
	}
	
	public  StatusReport editStatus(int strid)
	{
		// TODO Auto-generated method stub
		StatusReport str = null;
		String qry="select * from statusreport where Id = ?";
		try
		{
			PreparedStatement stmt= DBConnector.getPreparedStatement(qry);
			stmt.setInt(1,strid);
			ResultSet rs = stmt.executeQuery();
			if(rs.next())
			{
				str = new StatusReport();
				str.setComments(rs.getString(6));
				str.setComplianceid(rs.getInt(2));
				str.setDate1(rs.getString(7));
				str.setDeptid(rs.getInt(5));
				str.setEmpid(rs.getInt(4));
				str.setId(rs.getInt(1));
				str.setStatusreport(rs.getString(3));
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return str;
	}
	
	
	public   ArrayList<StatusReport> getEmpdetails(int dptid)
	{
		// TODO Auto-generated method stub
		StatusReport str = null;
		String qry="select * from statusreport where deptid = ?";
		System.out.println("1");
		ArrayList<StatusReport> list = new ArrayList<StatusReport>();

	
		try
		{
	    System.out.println("2");
		PreparedStatement pstmt = DBConnector.getPreparedStatement(qry);
		
		pstmt.setInt(1,dptid);
		
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{System.out.println("2");
			StatusReport sr = new StatusReport();
			
			sr.setComments(rs.getString(6));
			sr.setComplianceid(rs.getInt(2));
			sr.setDate1(rs.getString(7));
			sr.setDeptid(rs.getInt(5));
			sr.setEmpid(rs.getInt(4));
			sr.setId(rs.getInt(1));
			sr.setStatusreport(rs.getString(3));
			
			list.add(sr);		
		}
		
		}
	
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	
	public static String insertRegulations(StatusReport rp)
	{
		// TODO Auto-generated method stub
		System.out.println("in method");
		String s= null;
	String query ="insert into statusreport (id,complianceid,statusreport,empid,deptid,comments,createdate) values(?,?,?,?,?,?,?)";
	
	try
	{
		PreparedStatement pstmt= DBConnector.getPreparedStatement(query);
		pstmt.setInt(1,rp.id);
		pstmt.setInt(2,rp.complianceid);
		pstmt.setString(3,rp.statusreport);
		pstmt.setInt(4,rp.empid);
		pstmt.setInt(5,rp.deptid);
		pstmt.setString(6,rp.comments);
		pstmt.setString(7,rp.date1);
		
	
        
	int i = pstmt.executeUpdate();
	if(i==1)
	{
		s = Results.SUCCESS;
		System.out.println("success");
	}else
	{
		System.out.println("fail");
		s= Results.FAILIURE;
		
	}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	s = Results.PROBLEM;
	}
	return s;
}

	public  String updateStatus(StatusReport str) {
		// TODO Auto-generated method stub
		
		String query="update statusreport set complianceid = ?,statusreport = ?,empid = ?,deptid = ?,comments = ?,createdate = ? where Id = ?";
		String result= null;
		try{
			System.out.println("upddao");
			PreparedStatement pstmt= DBConnector.getPreparedStatement(query);
			
			pstmt.setInt(7, str.id);
			pstmt.setInt(1,str.complianceid);
			pstmt.setString(2,str.statusreport);;
			pstmt.setString(5,str.comments);
			pstmt.setInt(4,str.deptid);
			pstmt.setInt(3,str.empid);
			pstmt.setString(6,str.date1);
			System.out.println(query);
			int i = pstmt.executeUpdate();
			if(i==1)
			{result=Results.SUCCESS;}
			else
			{result=Results.FAILIURE;}
				
		}
		catch(Exception ex)
		{ex.printStackTrace();
		 result = Results.PROBLEM;
		
		}
		return result;
	}
}
