package com.ems.constants;

public class Results {

	public static  final String  SUCCESS="Success";
	public static  final String  FAILIURE="Failiure";
	public static  final String  PROBLEM="Problem";
	

}


