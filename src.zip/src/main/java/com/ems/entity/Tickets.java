package com.ems.entity;

public class Tickets
{

	public int tktid,empid;
	public String empname,status,ticket;
	public String crtdate;
	
	@Override
	public String toString() {
		return "Tickets [tktid=" + tktid + ", empid=" + empid + ", empname=" + empname + ", status=" + status
				+ ", ticket=" + ticket + ", crtdate=" + crtdate + "]";
	}
	public int getTktid() 
	{
		return tktid;
	}
	public void setTktid(int tktid) {
		this.tktid = tktid;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTicket() {
		return ticket;
	}
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}
	public String getCrtdate() {
		return crtdate;
	}
	public void setCrtdate(String crtdate) {
		this.crtdate = crtdate;
	}
	
	
}
