package com.ems.entity;



public class StatusReport {

	public  int id,complianceid,empid,deptid=0;
	public  String statusreport,comments=null;
	public  String date1;
	
	public String getDate1() {
		return date1;
	}

	public void setDate1(String date1) {
		this.date1 = date1;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public int getComplianceid() {
		return complianceid;
	}
	public void setComplianceid(int complianceid) {
		this.complianceid = complianceid;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getStatusreport() {
		return statusreport;
	}
	public void setStatusreport(String statusreport) {
		this.statusreport = statusreport;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
}
