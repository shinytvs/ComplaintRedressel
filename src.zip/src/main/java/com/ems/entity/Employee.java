package com.ems.entity;

//import java.util.Date;

public class Employee 
{
	public int empid;
	public String empname;
	public String lname;
	//public Date dob;
	public String dob;
	public int deptid;
	public String email;

	public Employee()
	{
		// TODO Auto-generated constructor stub
	}

	
	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//	@Override
//	public String toString() {
//		return "Employee [dob=" + dob + "]";
//	}
	
	

}
