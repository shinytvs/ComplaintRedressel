package com.ems.entity;

public class Booking 
{
private int bookingid;
private String email;
public int getBookingid() {
	return bookingid;
}
public void setBookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}

}
