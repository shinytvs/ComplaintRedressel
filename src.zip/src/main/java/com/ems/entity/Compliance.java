package com.ems.entity;

import java.sql.Date;

public class Compliance 
{ public int complianceid,deptid;
public String RLType,details;
public String crtdate;


	public Compliance() {
		// TODO Auto-generated constructor stub
	}


	public int getComplianceid() {
		return complianceid;
	}


	public void setComplianceid(int complianceid) {
		this.complianceid = complianceid;
	}


	public int getDeptid() {
		return deptid;
	}


	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}


	public String getRLType() {
		return RLType;
	}


	public void setRLType(String rLType) {
		RLType = rLType;
	}


	public String getDetails() {
		return details;
	}


	public void setDetails(String details) {
		this.details = details;
	}


	


	
	public String getCrtdate() {
		return crtdate;
	}


	public void setCrtdate(String crtdate) {
		this.crtdate = crtdate;
	}


	@Override
	public String toString() {
		return "Compliance [crtdate=" + crtdate + "]";
	}

}
