package com.ems.entity;

public class Department 
{
	public String deptname;
	public int deptid,deptno;
	public Department()
	{
		
		// TODO Auto-generated constructor stub
	}
	
	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
 
	
	
}
