package com.ems.dao;

import java.util.List;

import com.ems.entity.Employee;

public interface EmpDao 
{
	public List<Employee> getAllEmployee();
	   public Employee getEmployee(int empid);
	   public void updateEmployee(Employee emp);
	   public void deleteEmployee(Employee emp);
	   public void insertEmployee(Employee emp);
	
}
