package com.ems.dbconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConnector {

		static String user= "root";
		static String psw = "root";
		static String url = "jdbc:mysql://Localhost:3306/testdb";
		public static Connection getConnect()
		{
			Connection c = null;
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
			//	Class.forName("com.mysql.jdbc.Driver");
				c= DriverManager.getConnection(url,user,psw);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return c;
		}
		
		public static Statement getStatement()
		{
			Statement s = null;
			try
			{
				Connection c = getConnect();
				s = c.createStatement();
			}
			catch(Exception e)
			{e.printStackTrace();}
			return s;
		}
		
		public static PreparedStatement getPreparedStatement(String query)
		{
			
			PreparedStatement ps = null;
			try
			{
				Connection c = getConnect();
			    ps = c.prepareStatement(query); 	
				
			}
			catch(Exception e)
			{e.printStackTrace();}
			return ps;
			
		}
		public static ResultSet getResultSet(String query)

		{
			ResultSet rs = null;
			try
			{
				
				Statement s =getStatement();
			     rs = s.executeQuery(query);
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return rs;
		}
		
		public static ResultSet getResultSetpstmt(String query)

		{
			ResultSet rs = null;
			try
			{
				
				PreparedStatement ps = getPreparedStatement(query);
				rs = ps.executeQuery();
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return rs;
		}
	}


