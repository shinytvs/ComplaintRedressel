package com.ems.bo;

import java.util.Date;
import java.util.Locale;

import com.ems.entity.*;
import com.ems.constants.Results;
import com.ems.daoimpl.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class EmpInsServlet
 */
public class EmpInsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpInsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		System.out.println("updated");
		PrintWriter out = response.getWriter();
		System.out.println("updated");
		ValidateDao vd = new ValidateDao();
//		String s= request.getParameter("action");
//		System.out.println(s);	   
//			
			String id= request.getParameter("empid");
			int i = Integer.parseInt(id);
			System.out.println(id);
			String ename= request.getParameter("empname");
			System.out.println(ename);
			String lnm= request.getParameter("lname");
			String dob= request.getParameter("dob");
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.ENGLISH);
		//	Date date = format.parse(dob);
			SimpleDateFormat sdf =new SimpleDateFormat("yyyy-mm-dd");
			//Date dob1= sdf.parse(dob);
			String eml= request.getParameter("email");
			String dptid= request.getParameter("deptid");
			int deptid = Integer.parseInt(dptid);
			String t = vd.validateEmpid(i);
			System.out.println(t);
			if(vd.validateEmpid(i).equals("Success"))
			{out.println("id exist,try new one");
			
			}
			else
			{
				System.out.println("inside else");
			Employee e= new Employee();
			e.setEmpid(i);
			e.setEmpname(ename);
			e.setLname(lnm);
			e.setDob(dob);
			e.setEmail(eml);
			e.setDeptid(deptid);
			String r= EmployeeDaoImpl.insertEmployee(e);
			if(r.equals(Results.SUCCESS))
			{
				  out.println("data inserted successfully");
				
					//HttpSession ssn = request.getSession();
					//ssn.setAttribute("ename", s);
					//RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					//rd.forward(request, response);
			}
			else
			{out.print("not updated");}
			RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
			rd.forward(request, response);
			}
	}
		
		
	}

		
		



