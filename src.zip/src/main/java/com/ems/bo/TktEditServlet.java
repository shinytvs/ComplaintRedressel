package com.ems.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.constants.Results;
import com.ems.daoimpl.EmployeeDaoImpl;
import com.ems.daoimpl.TicketDaoImpl;
import com.ems.entity.Employee;
import com.ems.entity.Tickets;

/**
 * Servlet implementation class TktEditServlet
 */
public class TktEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TktEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		System.out.println("updated1");
		PrintWriter out = response.getWriter();
		System.out.println("updated2");
		String s= request.getParameter("action");
		System.out.println(s);
		if(s.equals("Save"))
		{    
			System.out.println("updated3");
			String id= request.getParameter("tktid");
			int i = Integer.parseInt(id);
			System.out.println(i);
			String empid= request.getParameter("empid");
			String tkt= request.getParameter("tkt");
			String status= request.getParameter("status");
			String empname= request.getParameter("empname");
			String crtdt= request.getParameter("crtdt");
			int emplid = Integer.parseInt(empid);
			System.out.println(emplid);
			Tickets e= new Tickets();
			e.setTktid(i);
			
			e.setEmpid(emplid);
			e.setTicket(tkt);
			e.setStatus(status);
			e.setEmpname(empname);
			e.setCrtdate(crtdt);
			
			
			System.out.println(e.empname);
			String r= TicketDaoImpl.updateTickets(e);
			System.out.println("into daoimpl");
			if(r.equals(Results.SUCCESS))
			{
				  out.println("updated");
				  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
			}
			else
			{
				System.out.println("not updates");
			out.print("not updated");
			RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
			rd.forward(request, response);}
			}
		else if(s.equals("Delete"))
		{
			String id2 = request.getParameter("tktid");
			   int n = Integer.parseInt(id2);
			   //AdminEntity  ae = new AdminEntity();
			   Employee ae=new Employee();
			   ae.setEmpid(n);
			   String sr= EmployeeDaoImpl.deleteEmployee(n);
			   System.out.println(sr);
			   if(sr.equals(Results.SUCCESS))
			   {out.println("deleted");
			   RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);}
			   else
			   {out.println("not deleted");
			   RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
				rd.forward(request, response);}
			}
		else
			{out.print("Please select an option");}
	}

		
		

}


