package com.ems.bo;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreatetktServlet
 */
public class CreatetktServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreatetktServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String id= request.getParameter("empid");
		int i = Integer.parseInt(id);
		System.out.println(id);
		String ename= request.getParameter("empname");
		System.out.println(ename);
		String lnm= request.getParameter("lname");
		String dob= request.getParameter("dob");
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.ENGLISH);
	//	Date date = format.parse(dob);
		SimpleDateFormat sdf =new SimpleDateFormat("yyyy-mm-dd");
		//Date dob1= sdf.parse(dob);
		String eml= request.getParameter("email");
		String dptid= request.getParameter("deptid");
		int deptid = Integer.parseInt(dptid);
	
	}

}
