package com.ems.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Date;  
import java.io.*;
import java.util.*;
import com.ems.constants.Results;
import com.ems.daoimpl.ComplianceDao;
import com.ems.entity.Compliance;


/**
 * Servlet implementation class RegInsServlet
 */
public class RegInsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegInsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		System.out.println("updated");
		PrintWriter out = response.getWriter();
		System.out.println("updated");
		
		String s= request.getParameter("action");
		System.out.println(s);
		    
			System.out.println("inserted");
			String id= request.getParameter("compid");
			int i = Integer.parseInt(id);
			String rltype= request.getParameter("rltype");
			String details= request.getParameter("details");
		    String dt= request.getParameter("date");
			
			Date dNow = new Date(i );
	        // SimpleDateFormat ft =   new SimpleDateFormat ("E yyyy-MM-dd");
			 SimpleDateFormat ft =   new SimpleDateFormat ("yyyy-MM-dd");
	         out.print( "<h3 align=\"left\">" + ft.format(dNow) + "</h3>");
			

			
			String dptid= request.getParameter("deptid");
			int deptid = Integer.parseInt(dptid);
			Compliance cp= new Compliance();
			cp.setComplianceid(i);
			cp.setRLType(rltype);
			cp.setDetails(details);
			cp.setCrtdate(ft.format(dNow));
			
			cp.setDeptid(deptid);
			String r= ComplianceDao.insertRegulations(cp);
			if(r.equals(Results.SUCCESS))
			{
				  out.println("updated");
				  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);;
			}
			else
			{out.print("not updated");
			RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
			rd.forward(request, response);}
			}
	
		
		
	}


