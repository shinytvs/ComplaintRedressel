package com.ems.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ems.constants.Results;
import com.ems.daoimpl.EmployeeDaoImpl;
import com.ems.daoimpl.StatusrpDao;
import com.ems.dbconnector.DBConnector;
import com.ems.entity.Employee;
import com.ems.entity.StatusReport;

/**
 * Servlet implementation class StatusRepServlet
 */
public class StatusRepServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StatusRepServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		System.out.println("updated");
		PrintWriter out = response.getWriter();
		
  
			System.out.println("updated1");
			String eid1= request.getParameter("empid");
			System.out.println("updated2");
			int eid2= Integer.parseInt(eid1);
			System.out.println("updated3");
			String cid1= request.getParameter("compid");
			
			int cid2 = Integer.parseInt(cid1);
			
			String dpt= request.getParameter("dptid");
			
			int dptid2 = Integer.parseInt(dpt);
		
			String id1= request.getParameter("id");
			
			int id2 = Integer.parseInt(id1);
			System.out.println("updated9");
			String cmts= request.getParameter("comments");
			
			String dob= request.getParameter("dt");
			String stat1= request.getParameter("stat");
			if(stat1.equals("closed"))
			{out.println("cannot update it is closed");}
			else
			{
				System.out.println("in1");
			StatusReport str = new StatusReport();
			str.setComments(cmts);
			str.setComplianceid(cid2);
			str.setDate1(dob);
			str.setDeptid(dptid2);
			str.setEmpid(eid2);
			str.setId(id2);
			str.setStatusreport(stat1);
			StatusrpDao std= new StatusrpDao();
			System.out.println("updated9");
			String r= std.updateStatus(str);
			if(r.equals(Results.SUCCESS))
			{
				  out.println("updated");
				  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
			}
			else
			{out.print("not updated");
			RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
			rd.forward(request, response);}
			}}
}