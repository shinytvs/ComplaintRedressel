package com.ems.bo;
import com.ems.entity.*;
import com.ems.constants.Results;
import com.ems.daoimpl.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmpEditServlet
 */
public class EmpEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		System.out.println("updated");
		PrintWriter out = response.getWriter();
		System.out.println("updated");
		String s= request.getParameter("action");
		System.out.println(s);
		if(s.equals("Save"))
		{    
			System.out.println("updated");
			String id= request.getParameter("empid");
			int i = Integer.parseInt(id);
			String ename= request.getParameter("empname");
			String lnm= request.getParameter("lname");
			String dob= request.getParameter("dob");
			String eml= request.getParameter("email");
			String dptid= request.getParameter("deptid");
			int deptid = Integer.parseInt(dptid);
			Employee e= new Employee();
			e.setEmpid(i);
			e.setEmpname(ename);
			e.setLname(lnm);
			e.setDob(dob);
			e.setEmail(eml);
			e.setDeptid(deptid);
			String r= EmployeeDaoImpl.updateEmployee(e);
			if(r.equals(Results.SUCCESS))
			{
				  out.println("updated");
				  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
			}
			else
			{out.print("not updated");
			RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
			rd.forward(request, response);}
			}
		else if(s.equals("Delete"))
		{
			String id2 = request.getParameter("empid");
			   int n = Integer.parseInt(id2);
			   //AdminEntity  ae = new AdminEntity();
			   Employee ae=new Employee();
			   ae.setEmpid(n);
			   String sr= EmployeeDaoImpl.deleteEmployee(n);
			   System.out.println(sr);
			   if(sr.equals(Results.SUCCESS))
			   {out.println("deleted");
			   RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);}
			   else
			   {out.println("not deleted");
			   RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
				rd.forward(request, response);}
			}
		else
			{out.print("Please select an option");}
	}
}
		
		



