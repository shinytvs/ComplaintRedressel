package com.ems.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.constants.Results;
import com.ems.daoimpl.DeptDao;

import com.ems.entity.Department;

/**
 * Servlet implementation class DeptInsServlet
 */
public class DeptInsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeptInsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		System.out.println("updated");
		PrintWriter out = response.getWriter();
		System.out.println("updated");
		//ValidateDao vd = new ValidateDao();
		String s= request.getParameter("action");
		System.out.println(s);
		    
			System.out.println("inserted");
			String id= request.getParameter("deptid");
			int deptid = Integer.parseInt(id);
			String dname= request.getParameter("deptname");
			
			String dptno= request.getParameter("deptno");
			int deptno = Integer.parseInt(dptno);
			
				System.out.println("inside else");
			Department dp = new Department();
				dp.setDeptid(deptid);
				dp.setDeptname(dname);
				dp.setDeptno(deptno);
			
			String r= DeptDao.insertDepartment(dp);
			if(r.equals(Results.SUCCESS))
			{
				  out.println("added");
				  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
			}
			else
			{out.print("not added");
			 RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
				rd.forward(request, response);}
			}
	}
		
		
	


