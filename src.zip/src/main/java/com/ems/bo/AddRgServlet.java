package com.ems.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.constants.Results;

import com.ems.daoimpl.StatusrpDao;

import com.ems.entity.StatusReport;

/**
 * Servlet implementation class AddRgServlet
 */
public class AddRgServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddRgServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		System.out.println("updated");
		PrintWriter out = response.getWriter();
		System.out.println("updated");
		
		String s= request.getParameter("action");
		System.out.println(s);
		    
			System.out.println("inserted");
			String cid= request.getParameter("compid");
			int cid1 = Integer.parseInt(cid);
			String eid= request.getParameter("emid");
			int eid1 = Integer.parseInt(eid);
			String id= request.getParameter("id");
			int id1 = Integer.parseInt(id);
			String did= request.getParameter("deptid");
			int did1 = Integer.parseInt(id);
			String stats1= request.getParameter("stats");
			String comm= request.getParameter("comments");
			
			Date dNow = new Date( );
	         SimpleDateFormat ft =   new SimpleDateFormat ("E yyyy-MM-dd");
	        
	         out.print( "<align=\"left\">" + ft.format(dNow));
			String s2= ft.format(dNow);

			StatusReport str = new StatusReport();
			str.setComplianceid(cid1);
			str.setComments(comm);
			str.setDate1(s2);
			str.setDeptid(did1);
			str.setEmpid(eid1);
			str.setId(id1);
			str.setStatusreport(stats1);
			
			
			String r = StatusrpDao.insertRegulations(str);
			
			if(r.equals(Results.SUCCESS))
			{
				  out.println("updated");
				  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);;
			}
			else
			{out.print("not updated");
			RequestDispatcher rd = request.getRequestDispatcher("failed.jsp");
			rd.forward(request, response);}
			}
	
		
		

	}


