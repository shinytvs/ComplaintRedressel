package com.ems.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ems.daoimpl.LoginDao;

/**
 * Servlet implementation class LoginValidation
 */
public class LoginValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginValidation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");  
		    PrintWriter out = response.getWriter();  
		    String r=request.getParameter("usertype");    
		    String n=request.getParameter("username");  
		    String p=request.getParameter("password"); 
		    System.out.println(r);
		    System.out.println(n);
		    System.out.println(p);
		   // action="LoginValidation"
		    if(LoginDao.validatelogin(r, n, p))
		    {  
		    	if(r.equals("Admin"))
		    	{
		    		System.out.println("inside sessionadmin"+n);
					HttpSession ssn = request.getSession();
					ssn.setAttribute("ename", n);
					RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
					rd.forward(request, response);
		    	}
		    	else if(r.equals("User"))
		    	{
		    		System.out.println("inside sessionadmin"+n);
					HttpSession ssn = request.getSession();
					ssn.setAttribute("ename", n);
					RequestDispatcher rd = request.getRequestDispatcher("user.jsp");
					///RequestDispatcher rd = request.getRequestDispatcher("StatusRepServlet");
					rd.forward(request, response);
		    	}
		    	else if(r.equals("Manager"))
		    	{
		    		System.out.println("inside session manager"+n);
					HttpSession ssn = request.getSession();
					ssn.setAttribute("ename", n);
					RequestDispatcher rd = request.getRequestDispatcher("dptHd.jsp");
					rd.forward(request, response);
		    	}
		    	else if(r.equals("Engineer"))
		    	{
		    		System.out.println("inside session Engineerr"+n);
					HttpSession ssn = request.getSession();
					ssn.setAttribute("ename", n);
					RequestDispatcher rd = request.getRequestDispatcher("ViewComplaints.jsp");
					rd.forward(request, response);
		    	}
		    	else
		    	{
		    		out.print("Check the role entered");  
			        RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
			        rd.include(request,response);  
		    	}
		    }  
		    else{  
		        out.print("Sorry username or password error");  
		        RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
		        rd.include(request,response);  
		    }  
		          
		    out.close();  
		    }  
	}


