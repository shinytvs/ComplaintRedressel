package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CRUDController
{
	
	@Autowired
	StudentDao sd;
	@RequestMapping("insert")
	public ModelAndView insert(@RequestParam("name") String name,@RequestParam("email") String email,HttpServletRequest res,HttpServletResponse rep)
	{
	ModelAndView mv= new ModelAndView();
	Student s=new Student();
	s.setName(name);
	s.setEmail(email);
   Student sp=sd.insertStident(s);
	if(sp!=null)
	{mv.setViewName("status");
	
	}
	return mv;}
	
	@RequestMapping("getall")
	public ModelAndView get(HttpServletRequest res,HttpServletResponse rep)
	{
	ModelAndView mv= new ModelAndView();
	List<Student> s =sd.getAll();
	mv.setViewName("display");
	mv.addObject("list",s);
	return mv;
	}

	
	@RequestMapping("register")
	public ModelAndView register(@RequestParam("email") String email,HttpServletRequest res,HttpServletResponse rep)
	{
	ModelAndView mv= new ModelAndView();
	Student s=new Student();
	//s.setName(name);
	s.setEmail(email);
   
	Student sp=sd.getbyemail(email);
	if(sp!=null)
	{mv.setViewName("login");
	}
	return mv;
	
	
	
	}	
}
