package com.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootappDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootappDbApplication.class, args);
	}

}
